
* In first run the servd and make sure it doesn't get killed.
* Secondly run the scp with arguments like normal SCP does.
* Like ./scp filename jaiveer@192.168.12.148:/path
* Like ./scp -r Dirpath jaiveer@192.168.12.148:/path
* Sorry I have not gave any print statement to indicate it is sending.
* Because of some timing issues.

