/*
 * =====================================================================================
 *
 *       Filename:  Server.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  Monday 23 July 2018 11:59:15  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jaiveer (), sp.Jaiveer@gmail.com
 *   Organization:  Thinkodd Corporation
 *
 * =====================================================================================
 */

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/socket.h>
#include<netdb.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<signal.h>
#include<errno.h>
#include<sys/types.h>
#include<ifaddrs.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/sendfile.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/types.h>
#include<dirent.h>
#include<libgen.h>
#include "Send_Recv.h"

#define TEMPSIZE 1000
#define PORT 9876
#define BACKLOG 5
#define MAXSIZE 50000

int AcceptClient(int,struct sockaddr_in *);
void System_Ip(char *);
int MakeServer(char *);
int Init_Setup_Server();
int SendMessage(int, char *);
int RecvMessage(int ,char *);
int Authentication(char *,char *);
int Operation(int);
int Check(int, char *,char *);
int FN(int,char *,int);
int RN(int,char *,int);
int FR(int,char *,int);
int RR(int,char *,int);
void Penetrator(char *,int);
void Checker(struct dirent *,char *,int,int);

void main() {
	int SSockFd,CSockFd,PID,Status;
	char *Exit=(char *) malloc(sizeof(char)*TEMPSIZE);
	strcpy(Exit,"EXIT");
	struct sockaddr_in Client;
	if((SSockFd=Init_Setup_Server())!=-1) {
AcceptClient:
		if((CSockFd=AcceptClient(SSockFd,&Client))!=-1) {
			if((PID=fork())==0) {
				Status=Operation(CSockFd);
				SendMessage(CSockFd,Exit);
				exit(Status);
			}
			goto AcceptClient;
		}
	}
}

int Init_Setup_Server() {
	char *Ip=(char *) malloc(sizeof(char)*TEMPSIZE);
	int SockFd;
	System_Ip(Ip);
	if((SockFd=MakeServer(Ip))!=-1) {
		return SockFd;
	} else {
		printf("ERROR: Server cannot start\n");
		return -1;
	}
}

void System_Ip(char *Ip) {
	struct ifaddrs *ifaddr, *ifa;
	int family, s;
	getifaddrs(&ifaddr);
	for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) 
	{
		if (ifa->ifa_addr == NULL)
			continue;  
		s=getnameinfo(ifa->ifa_addr,sizeof(struct sockaddr_in),Ip, NI_MAXHOST, NULL, 0, NI_NUMERICHOST);
		if((strcmp(ifa->ifa_name,"wlan0")==0)&&(ifa->ifa_addr->sa_family==AF_INET))
		{
			;
		}
	}
	freeifaddrs(ifaddr);
}

int MakeServer(char *Ip) {
	int SockFd=0,yes=1;
	struct sockaddr_in Server;
	Server.sin_family=AF_INET;
	Server.sin_port=htons(PORT);
	inet_pton(AF_INET,Ip,&Server.sin_addr.s_addr);
	bzero(&(Server.sin_zero),8);
	if((SockFd=socket(AF_INET,SOCK_STREAM,0))==-1) {
		printf("Error : Cannot Get Socket Descriptor\n");
		return -1;
	}
	if((setsockopt(SockFd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int))) == -1) {
		printf("Error : Cannot Reuse Address\n");
		return -1;
	}
	if((bind(SockFd,(struct sockaddr *) &Server,sizeof(struct sockaddr)))==-1) {
		printf("Error : Cannot Bind port : %s\n",strerror(errno));
		return -1;
	}
	if((listen(SockFd,BACKLOG))==-1) {
		printf("Error : Cannot listen port\n");
		return -1;
	}
	return SockFd;
}

int AcceptClient(int SockFd,struct sockaddr_in *Client) {
	int CSize=0,CSockFd=0;
	if((CSockFd=accept(SockFd,(struct sockaddr *)Client,&CSize))==-1) {
		printf("Error : Cannot Obtain New Socket Descriptor\n");
		return -1;
	}
	return CSockFd;
}

int SendMessage(int SockFd,char *Message) {
	char *Send_Content=(char *) malloc(sizeof(char)*TEMPSIZE),Return=0;
	if(Message!=NULL) {
		sprintf(Send_Content,"%.10d%s",strlen(Message),Message);
		Return=send(SockFd,Send_Content,strlen(Send_Content),0);
	}
	if(Return==0) {
		printf("ERROR: Client Aborted (%s)\n",strerror(ECONNABORTED));
		exit(ECONNABORTED);
	} else if(Return==-1) {
		printf("ERROR: Recieving data failute (%s)\n",strerror(errno));
		exit(errno);
	} else {
		return Return;
	}
}

int RecvMessage(int SockFd,char *Message) {
	char *RecvSize=(char *) malloc(sizeof(char)*50),Return;
	int Size=0;
	Return=recv(SockFd,RecvSize,10,0);
	Size=atoi(RecvSize);
	Return=recv(SockFd,Message,Size,0);
	Message[Size]='\0';
	Message[Size+1]='\0';
	if(Return==0) {
		printf("ERROR: Client Aborted (%s)\n",strerror(ECONNABORTED));
		exit(ECONNABORTED);
	} else if(Return==-1) {
		printf("ERROR: Recieving data failute (%s)\n",strerror(errno));
		exit(errno);
	} else {
		return Return;
	}
}

int Check(int NOF,char *Destination,char *Tot) {
	struct stat Dest_Stat;
	if((stat(Destination,&Dest_Stat))==0) {
		if((strcmp(Tot,"FN"))==0) {
			if(NOF==1) {
				if(S_ISREG(Dest_Stat.st_mode)) {
					return 1;
				} else if(S_ISDIR(Dest_Stat.st_mode)) {
					if(*(Destination+strlen(Destination)-1)!='/') 
						strcat(Destination,"/");
					return 1;
				} 
			} else if(NOF>1) {
				if(S_ISDIR(Dest_Stat.st_mode)) {
					if(*(Destination+strlen(Destination)-1)!='/') 
						strcat(Destination,"/");
					return 1;
				}
			}
		} else if((strcmp(Tot,"RN"))==0) {
			if(S_ISREG(Dest_Stat.st_mode) && NOF==1) {
				return 2;
			}
		} else if((strcmp(Tot,"FR"))==0) {
			if(S_ISDIR(Dest_Stat.st_mode)) {
				if(*(Destination+strlen(Destination)-1)!='/') 
					strcat(Destination,"/");
				return 3;
			}
		} else if((strcmp(Tot,"RR"))==0) {
			if(S_ISDIR(Dest_Stat.st_mode) && NOF==1) {
				if(*(Destination+strlen(Destination)-1)!='/') 
					strcat(Destination,"/");
				return 4;
			}
		}
	}
	return 0;
}

int Operation(int SockFd) {
	char *Message=(char *) malloc(sizeof(char)*TEMPSIZE),*UserName,*Password,*Tot,*Nof,*Dest,*Path=(char *) malloc(sizeof(char)*TEMPSIZE);
	int NOF=0,Return;
	bzero(Message,sizeof(Message));
	if((Return=RecvMessage(SockFd,Message))>0) {
		UserName=strtok(Message,"|");	
		Password=strtok(NULL,"|");
		Tot=strtok(NULL,"|");
		Nof=strtok(NULL,"|");
		NOF=atoi(Nof);
		Dest=strtok(NULL,"|");
		strcpy(Path,Dest);
		if(Authentication(UserName,Password)) {
			switch(Check(NOF,Path,Tot)) {
				case 1: 
					if(FN(SockFd,Path,NOF)) {
						return 0;
					}
					return -1;
					break;
				case 2: 
					if(RN(SockFd,Path,NOF)) {
						return 0;
					}
					return -1;
					break;
				case 3: 
					if(FR(SockFd,Path,NOF)) {
						return 0;
					}
					return -1;
					break;
				case 4: 
					printf("Reverse Recursive\n");
					if(RR(SockFd,Path,NOF)) {
						return 0;
					}
					return -1;
					break;
				default:
					printf("ERROR: Operation cannot be permitted\n");
					return EPERM;
			}
		}
	}
	printf("ERROR: Authentication Failure\n");
	return EPERM; 
}

int Authentication(char *UserName,char *Password) {
	char *Auth_Log_File=(char *) malloc(sizeof(char)*TEMPSIZE),*Auth_Log=(char *) malloc(sizeof(char)*TEMPSIZE);
	char *Log_UserName=(char *) malloc(sizeof(char)*TEMPSIZE),*Log_Password=(char *) malloc(sizeof(char)*TEMPSIZE);
	FILE *Auth_Logs;
	int Times;
	Auth_Log_File=getenv("HOME");
	strcat(Auth_Log_File,"/");
	strcat(Auth_Log_File,"User_Log");
	Auth_Logs=fopen(Auth_Log_File,"r");
	if(Auth_Logs!=NULL) {
		while((Auth_Log=fgets(Auth_Log,TEMPSIZE,Auth_Logs))!=NULL) {
			if((strcmp(Auth_Log,"\n"))!=0) {
				*(Auth_Log+strlen(Auth_Log)-1)='\0';
				if((strchr(Auth_Log,'|'))!=NULL) {
					Log_UserName=strtok(Auth_Log,"|");
					Log_Password=strtok(NULL,"|");
					if((strcmp(Log_UserName,UserName))==0 && (strcmp(Log_Password,Password))==0) {
						return 1;		
					} else {
						while(1) {

						}
					}
				}
			}
		}
	}
	return 0;
}

int FN(int CSockFd,char *Path,int NOF) {
	int Loop=0;
	char *FileName=(char *) malloc(sizeof(char)*TEMPSIZE),*Destination=(char *) malloc(sizeof(char)*TEMPSIZE),*Status=(char *) malloc(sizeof(char)*TEMPSIZE);
	FILE *File;
	SendMessage(CSockFd,Path);
	while(Loop<(NOF+1)) {
		strcpy(Destination,Path);
		RecvMessage(CSockFd,FileName);
		if((strcmp(FileName,"EXIT"))==0) {
			break;
		}
		if(Path[(strlen(Path)-1)]=='/') {
			strcat(Destination,FileName);
		}
		if((File=fopen(Destination,"w"))!=NULL) {
			RecvFile(CSockFd,File,FileName);
			fclose(File);
		}
		SendMessage(CSockFd,"RECIEVED\0");
		Loop++;
	}
	return 0;
}

int RN(int CSockFd,char *Path,int NOF) {
	int Fd;
	struct stat Buffer;
	char *Status=(char *) malloc(sizeof(char)*TEMPSIZE);
	if((Fd=open(Path,O_RDONLY))!=-1) {
		SendMessage(CSockFd,Path);
		RecvMessage(CSockFd,Status);
		if((strcmp(Status,"EXIT"))==0) {
			return 0;
		}
		fstat(Fd,&Buffer);
		SendFile(CSockFd,Fd,(int) Buffer.st_size,Path);
	}
	RecvMessage(CSockFd,Status);
}

int FR(int CSockFd,char *Path,int NOF) {
	char *Files=(char *) malloc(sizeof(char)*TEMPSIZE);
	char *ToCreate=(char *) malloc(sizeof(char)*TEMPSIZE);
	FILE *File;
	SendMessage(CSockFd,Path);
	RecvMessage(CSockFd,Files);
	while((strcmp(Files,"EXIT"))!=0) {
		strcpy(ToCreate,Path);
		printf("The path to create is %s\n",ToCreate);
		if(Files[0]=='/') {
			strcat(ToCreate,(Files+1));
		} else {
			strcat(ToCreate,Files);
		}
		if(ToCreate[(strlen(ToCreate)-1)]=='/') {
			mkdir(ToCreate,0777);
		} else {
			if((File=fopen(ToCreate,"w"))!=NULL) {
				SendMessage(CSockFd,"SEND\0");
				RecvFile(CSockFd,File,ToCreate);
				fclose(File);
			} else {
				SendMessage(CSockFd,"DONOTSEND\0");
			}
		}
		RecvMessage(CSockFd,Files);
	}
}

int RR(int CSockFd,char *Path,int NOF) {
	char *PathName=(char *) malloc(sizeof(char)*TEMPSIZE),*Status=(char *) malloc(sizeof(char)*TEMPSIZE);;
	char *Directory,*Temprovary=(char *) malloc(sizeof(char)*TEMPSIZE);
	int Fd;
	struct stat Buffer;
	SendMessage(CSockFd,Path);
	strcpy(PathName,Path);
	if((stat(PathName,&Buffer))!=-1) {
		if(S_ISDIR(Buffer.st_mode)) {
			if(PathName[strlen(PathName)-1]!='/') {
				strcat(PathName,"/");
			}
			PathName[strlen(PathName)-1]='\0';
			printf("%s\n",PathName);
			chdir(PathName);
			chdir("../");
			strcpy(Temprovary,PathName);
			if(Temprovary[strlen(Temprovary)-1]=='/')
			Temprovary[strlen(Temprovary)-1]='\0';
			Directory=basename(Temprovary);
			strcat(Directory,"/");
			SendMessage(CSockFd,Directory);
			printf("ohhohohoh %s\n",Directory);
			Penetrator(Directory,CSockFd);
		} else if(S_ISREG(Buffer.st_mode)) {
			if((Fd=open(PathName,O_RDONLY))!=-1) {
				SendMessage(CSockFd,Path);
				RecvMessage(CSockFd,Status);
				if((strcmp(Status,"DONOTSEND"))==0) {
					return 0;
				}
				fstat(Fd,&Buffer);
				SendFile(CSockFd,Fd,(int) Buffer.st_size,Path);
			}
		}
	}
	SendMessage(CSockFd,"EXIT\0");
}

void Penetrator(char *Ptr,int SockFd) {
	char Path[300];
	DIR *Dp;
	struct dirent *FileNames;
	struct stat *FileProp;
	strcpy(Path,Ptr);
	if((Dp=opendir(Ptr))!=NULL) {
		do {
			if((FileNames=readdir(Dp))!=NULL) {
				if(FileNames->d_type==8) {
					Checker(FileNames,Path,0,SockFd);
				} else if(FileNames->d_type==4 && ((strcmp(FileNames->d_name,".."))!=0) && ((strcmp(FileNames->d_name,"."))!=0) ) {
					sprintf(Path,"%s/%s",Path,FileNames->d_name);
					Checker(FileNames,Path,1,SockFd);
					Penetrator(Path,SockFd);
					sprintf(Path,"%s",Ptr);
				}
			}
		} while(FileNames!=NULL);
		closedir(Dp);
	}
}

void Checker(struct dirent *FileName,char *Ptr,int Type,int SockFd) {
	char *Path=(char *) malloc((sizeof(char)*(TEMPSIZE*10)));
	char *Status=(char *) malloc((sizeof(char)*(TEMPSIZE)));
	struct stat Buffer;
	int Fd;
	if(Type==0) {
		sprintf(Path,"%s/%s",Ptr,FileName->d_name);
		printf("FileName %s\n",Path);
		SendMessage(SockFd,Path);
		if((Fd=open(Path,O_RDONLY))!=-1) {
			fstat(Fd,&Buffer);
			RecvMessage(SockFd,Status);
			if((strcmp(Status,"SEND"))==0) {
				SendFile(SockFd,Fd,(int) Buffer.st_size,Path);
			}
		}
	} else if(Type==1) {
		sprintf(Path,"%s/",Ptr);
		SendMessage(SockFd,Path);
	}
	free(Path);
}
