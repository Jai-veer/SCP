/*
 * =====================================================================================
 *
 *       Filename:  Send_Recv.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  Tuesday 28 August 2018 11:24:20  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jaiveer (), sp.Jaiveer@gmail.com
 *   Organization:  Think and Work Corporation
 *
 * =====================================================================================
 */
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#define MAXSIZE 50000
#define TEMPSIZE 1000

int SendFile(int,int,int, char *);
void RecvFile(int,FILE *,char *);

int SendFile(int SockFd,int Fd,int Size,char *FileName) {
	off_t Offset=0;
	char *SizeInChar=(char *) malloc(sizeof(char)*TEMPSIZE);
	float Percentage=0;
	int TotalSent=0;
	sprintf(SizeInChar,"%.20d",Size);
	send(SockFd,SizeInChar,strlen(SizeInChar),0);
	int SendLen=0,ToSend,RemainLen=Size;
	while(1) {
		if(RemainLen>50000) {
			ToSend=MAXSIZE;
		} else {
			ToSend=RemainLen;
		}
		sprintf(SizeInChar,"%.10d",ToSend);
		if(ToSend>0) {
			if((send(SockFd,SizeInChar,strlen(SizeInChar),0))>0)
				;
			sleep(1);
			if((SendLen=sendfile(SockFd,Fd,&Offset,ToSend))>0) {
				sleep(1);
				//printf("This is the send len : %d : Total size : %d\n",SendLen,Size);
				TotalSent+=SendLen;
				Percentage=(float )TotalSent/Size*100.0;
				printf("\r%.85s\t\t\t\t\t\t\t\t%d%%\t\t%d\t\t%dKB/s",FileName,(int ) Percentage,Size,ToSend);
				fflush(stdout);
			}
			RemainLen-=SendLen;
		} else {
			if((send(SockFd,"FINISHED.!\0",strlen("FINISHED.!\0"),0))>0)
				;
			break;
		}
	}
	printf("\n");
	if((recv(SockFd,SizeInChar,10,0))>0)
		;

}

void RecvFile(int SockFd,FILE *File,char *FileName) {
	char *Buffer=(char *) malloc(sizeof(char)*MAXSIZE+2);
	char *SizeInChar=(char *) malloc(sizeof(char)*MAXSIZE+2);
	int TotalGot=0;
	float Percentage;
	recv(SockFd,Buffer,20,0);
	int Size=atoi(Buffer),ToGet;
	int GetSize=Size,RecvLen;
	bzero(Buffer,sizeof(Buffer));
	while(1) {
		if((recv(SockFd,SizeInChar,10,0))>0)
			if((strcmp(SizeInChar,"FINISHED.!"))!=0) {
				GetSize=atoi(SizeInChar);
				if(GetSize<MAXSIZE) {
					ToGet=GetSize;
				} else {
					ToGet=MAXSIZE;
				} 
				while(ToGet>0) {
					if((RecvLen=recv(SockFd,Buffer,ToGet,0))>0) {
						fwrite(Buffer,sizeof(char),RecvLen,File);
						//printf("\nThis is recvlen : %d : Size in total : %d\n",RecvLen,Size);
						TotalGot+=RecvLen;
						Percentage=(float )TotalGot/Size*100.0;
						printf("\r%.85s\t\t\t\t\t\t\t\t%d%%\t\t%d\t\t%dKB/s",FileName,(int )Percentage,Size,RecvLen);
						fflush(stdout);
						ToGet-=RecvLen;
					}
				}
			} else {
				break;
			}
	}
	printf("\n");
	if((send(SockFd,"GOTITRIGHT\0",strlen("GOTITRIGHT\0"),0))>0)
		;
}
