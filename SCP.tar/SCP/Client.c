/*
 * =====================================================================================
 *
 *       Filename:  Client.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  Monday 23 July 2018 11:59:27  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jaiveer (), sp.Jaiveer@gmail.com
 *   Organization:  Thinkodd Corporation
 *
 * =====================================================================================
 */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>       
#include<sys/socket.h>
#include<arpa/inet.h>
#include<errno.h>
#include<sys/sendfile.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/types.h>
#include<dirent.h>
#include<libgen.h>
#include "Send_Recv.h"

#define TEMPSIZE 1000
#define PORT 9876
#define MAXSIZE 50000

char *Organizer(int,char *[]);
char *Checker(char *);
char *GetPassword(char *,char *);
int ConnectServer(char *);
int SendMessage(int,char *);
int RecvMessage(int,char *);
int Operation(int,int,char *[]);
int FN(int, char *);
int RN(int, char *);
int FR(int, char *);
int RR(int, char *);
void Penetrator(char *,int);
void Check(struct dirent *,char *,int ,int);

int Type=0;

void main(int argc,char *argv[]) {
	char *FormInput,*Ip,*Request,*Status=(char *) malloc(sizeof(char)*TEMPSIZE),*Back_Argv[argc];
	int SSockFd,Return,Loop=0;
	while(Loop<argc) {
		Back_Argv[Loop]=(char *) malloc(sizeof(char)*TEMPSIZE);
		strcpy(Back_Argv[Loop],argv[Loop]);
		Loop++;
	}
	if((FormInput=Organizer(argc,argv))!=NULL) {
		Ip=strtok(FormInput,"@");
		Request=strtok(NULL,"@");
		if((SSockFd=ConnectServer(Ip))!=-1) {
			if((Return=SendMessage(SSockFd,Request))>0) {
				if((Return=Operation(SSockFd,argc,Back_Argv))!=-1) {
					RecvMessage(SSockFd,Status);
				}
			}
		}
	}
}

char *Organizer(int argc,char *argv[]) {
	int Loop=1;
	char *Log,*Password,*Request=(char *) malloc(sizeof(char)*TEMPSIZE),*Ip,*UserName,*Path,*Temp=(char *) malloc(sizeof(char)*TEMPSIZE);;
	if(argc>=2) {
		if((strcmp(argv[1],"-r"))==0) {
			if(argc>=3) {
				if((Log=Checker(argv[2]))!=NULL) { 
					Ip=strtok(Log,"@|");
					UserName=strtok(NULL,"@|");
					Password=GetPassword(UserName,Ip);
					Path=strtok(NULL,"@|");
					sprintf(Request,"%s@%s|%s|RR|%d|%s",Ip,UserName,Password,(argc-3),Path);
					Type=4;
					return Request;
				} else if((Log=Checker(argv[argc-1]))!=NULL) {
					Ip=strtok(Log,"@|");
					UserName=strtok(NULL,"@|");
					Password=GetPassword(UserName,Ip);
					Path=strtok(NULL,"@|");
					sprintf(Request,"%s@%s|%s|FR|%d|%s",Ip,UserName,Password,(argc-3),Path);
					Type=3;
					return Request;
				}
			}
			return NULL;
		} else {
			if(argc>=2) {
				if((Log=Checker(argv[1]))!=NULL) {
					Ip=strtok(Log,"@|");
					UserName=strtok(NULL,"@|");
					Password=GetPassword(UserName,Ip);
					Path=strtok(NULL,"@|");
					sprintf(Request,"%s@%s|%s|RN|%d|%s",Ip,UserName,Password,(argc-2),Path);
					Type=2;
					return Request;
				} else if((Log=Checker(argv[argc-1]))!=NULL) {
					Ip=strtok(Log,"@|");
					UserName=strtok(NULL,"@|");
					Password=GetPassword(UserName,Ip);
					Path=strtok(NULL,"@|");
					sprintf(Request,"%s@%s|%s|FN|%d|%s",Ip,UserName,Password,(argc-2),Path);
					Type=1;
					return Request;
				}
			}
			return NULL;
		}
	}
	return NULL;
}

char *GetPassword(char *UserName,char *Ip) {
	char *Password;
	char *Temp=(char *) malloc(sizeof(char)*TEMPSIZE);
	sprintf(Temp,"%s@%s's Password : ",UserName,Ip);
	Password=getpass(Temp);
	return Password;
}

char *Checker(char String[]) {
	char *UserName,*Ip,*Path,*Log=(char *) malloc(sizeof(char)*TEMPSIZE),*Ip_Full=(char *) malloc(sizeof(char)*TEMPSIZE),*Ip_Seg;
	int Ip_Segment=0,Loop=3,Flag=0;
	if((strchr(String,'@'))!=NULL && (strchr(String,':'))!=NULL) {
		UserName=strtok(String,"@:");
		Ip=strtok(NULL,"@:");
		strcpy(Ip_Full,Ip);
		Path=strtok(NULL,"@:");
		if(Path==NULL) {
			Path=(char *) malloc(sizeof(char)*TEMPSIZE);
			strcpy(Path,"/tmp");
		}
		if(Ip!=NULL) {
			Ip_Seg=strtok(Ip,".");
			if(Ip_Seg==NULL) {
				goto Finish;
			}
			Ip_Segment=atoi(Ip_Seg);
			while(Loop!=0 && Flag!=1) {
				if(Ip_Segment<0 && Ip_Segment>255) {
					Flag=1;	
					break;
				}
				Ip_Seg=strtok(NULL,".");
				if(Ip_Seg==NULL) {
					break;
				}
				Ip_Segment=atoi(Ip_Seg);
				Loop--;
			}
		}
Finish:
		if(Flag==1 || Loop!=0) {
			return NULL;
		} else {
			sprintf(Log,"%s@%s|%s",Ip_Full,UserName,Path);
			return Log;
		}
	} 
	return NULL;
}

int ConnectServer(char *Ip) {
	int SockFd;
	struct sockaddr_in Server;
	Server.sin_family=AF_INET;
	Server.sin_port=htons(PORT);
	inet_pton(AF_INET,Ip,&Server.sin_addr.s_addr);
	bzero(&(Server.sin_zero),8);
	if((SockFd=socket(AF_INET,SOCK_STREAM,0))==-1) {
		printf("Error : Cannot get Socket Descriptor\n");
		return -1;
	}
	if((connect(SockFd,(struct sockaddr *)&Server,sizeof(struct sockaddr)))==-1) {
		printf("Error : Failed to connect to host\n");
		return -1;
	}
	return SockFd;
}

int SendMessage(int SockFd,char *Message) {
	char *Send_Content=(char *) malloc(sizeof(char)*TEMPSIZE),Return=0;
	if(Message!=NULL) {
		sprintf(Send_Content,"%.10d%s",strlen(Message),Message);
		Return=send(SockFd,Send_Content,strlen(Send_Content),0);
	}
	if(Return==0) {
		printf("ERROR: Client Aborted (%s)\n",strerror(ECONNABORTED));
		exit(ECONNABORTED);
	} else if(Return==-1) {
		printf("ERROR: Recieving data failute (%s)\n",strerror(errno));
		exit(errno);
	} else {
		return Return;
	}
}

int RecvMessage(int SockFd,char *Message) {
	char *RecvSize=(char *) malloc(sizeof(char)*50),Return;
	int Size=0;
	Return=recv(SockFd,RecvSize,10,0);
	Size=atoi(RecvSize);
	Return=recv(SockFd,Message,Size,0);
	Message[Size]='\0';
	Message[Size+1]='\0';
	if(Return==0) {
		printf("ERROR: Client Aborted (%s)\n",strerror(ECONNABORTED));
		exit(ECONNABORTED);
	} else if(Return==-1) {
		printf("ERROR: Recieving data failute (%s)\n",strerror(errno));
		exit(errno);
	} else {
		return Return;
	}
}

int Operation(int SockFd,int argc,char *argv[]) {
	int Loop=0;
	char *FileName=(char *) malloc(sizeof(char)*TEMPSIZE);
	strcpy(FileName,"");
	switch(Type) {
		case 1: 
			Loop=1;
			while(Loop<(argc-1)) {
				strcat(FileName,argv[Loop]);
				strcat(FileName,":");
				Loop++;
			}
			return (FN(SockFd,FileName));
			break;
		case 2:
			Loop=2;
			while(Loop<argc) {
				strcat(FileName,argv[Loop]);
				strcat(FileName,":");
				Loop++;
			}
			return (RN(SockFd,FileName));
			break;
		case 3:
			Loop=2;
			while(Loop<(argc-1)) {
				strcat(FileName,argv[Loop]);
				strcat(FileName,":");
				Loop++;
			}
			return (FR(SockFd,FileName));
			break;
		case 4:
			Loop=3;
			while(Loop<argc) {
				strcat(FileName,argv[Loop]);
				strcat(FileName,":");
				Loop++;
			}
			return (RR(SockFd,FileName));
			break;
	}
}
int Authentication() {

}

int FN(int SockFd, char *FileName) {
	char *Status=(char *) malloc(sizeof(char)*TEMPSIZE),*FileNames=(char *) malloc(sizeof(char)*(strlen(FileName)+10)),*File,*ToSend;
	int Fd;
	struct stat Buffer;
	if(FileName!=NULL) {
		strcpy(FileNames,FileName);
	}
	RecvMessage(SockFd,Status);
	if((strcmp(Status,"EXIT"))!=0) {
		File=strtok(FileName,":");
		while(File!=NULL) {
			if((Fd=open(File,O_RDONLY))!=-1) {
				ToSend=basename(File);
				SendMessage(SockFd,ToSend);	
				fstat(Fd,&Buffer);
				SendFile(SockFd,Fd,(int) Buffer.st_size,ToSend);
				RecvMessage(SockFd,Status);
			}
			File=strtok(NULL,":");
		}
	} else {
		printf("Error : Failed to connect to host\n");
		exit(ECONNREFUSED);
	}
	SendMessage(SockFd,"EXIT\0");
}

int RN(int SockFd, char *FileName) {
	char *Status=(char *) malloc(sizeof(char)*TEMPSIZE),*FileNames=(char *) malloc(sizeof(char)*(strlen(FileName)+10)),*Files;
	FILE *File;
	if(FileName!=NULL) {
		strcpy(FileNames,FileName);
	}
	RecvMessage(SockFd,Status);
	if((strcmp(Status,"EXIT"))!=0) {
		Files=strtok(FileName,":");
		if((File=fopen(Files,"w"))!=NULL) { 
			SendMessage(SockFd,Files);
			RecvFile(SockFd,File,Files);
			fclose(File);
		} else {
			strcpy(Status,"EXIT");
			SendMessage(SockFd,Status);
		}
	} else {
		printf("Error : Failed to connect to host\n");
		exit(ECONNREFUSED);
	}
	strcpy(Status,"EXIT");
	SendMessage(SockFd,Status);
}

int FR(int SockFd, char *FileName) {
	char *Status=(char *) malloc(sizeof(char)*TEMPSIZE);
	char *File=(char *) malloc(sizeof(char)*TEMPSIZE),*Files;
	struct stat Buffer;
	int Fd;
	RecvMessage(SockFd,Status);
	if((strcmp(Status,"EXIT"))!=0) {
		Files=strtok(FileName,":");
		while(Files!=NULL) {
			strcpy(File,Files);
			if((stat(File,&Buffer))!=-1) {
				if(S_ISDIR(Buffer.st_mode)) {
					if(File[(strlen(File)-1)]!='/') {
						strcat(File,"/");
					}
					SendMessage(SockFd,File);
					if(File[(strlen(File)-1)]=='/') {
						File[(strlen(File)-1)]='\0';
					}
					Penetrator(File,SockFd);
				} else if(S_ISREG(Buffer.st_mode)) {
					SendMessage(SockFd,File);
					if((Fd=open(File,O_RDONLY))!=-1) {
						fstat(Fd,&Buffer);
						RecvMessage(SockFd,Status);
						if((strcmp(Status,"SEND"))==0) {
							SendFile(SockFd,Fd,(int) Buffer.st_size,File);
						} else {
							printf("ERR: Cannot Process Request\n");
						}
					}
				}
			}
			Files=strtok(NULL,":");
		} 
	}
	SendMessage(SockFd,"EXIT\0");
}

int RR(int SockFd, char *FileName) {
	char *Status=(char *) malloc(sizeof(char)*TEMPSIZE),*Path=(char *) malloc(sizeof(char)*TEMPSIZE),*DirPath;
	char *ToCreate=(char *) malloc(sizeof(char)*TEMPSIZE);
	FILE *File;
	DirPath=strtok(FileName,":");
	RecvMessage(SockFd,Status);
	if((strcmp(Status,"EXIT"))!=0) {
		RecvMessage(SockFd,Path);
			printf("This is the path came : %s\n",Path);
		while((strcmp(Path,"EXIT"))!=0) {
			if(Path[strlen(Path)-1]=='/') {
				strcpy(ToCreate,DirPath);
				strcat(ToCreate,Path);
				mkdir(ToCreate,0777);	
			} else {
				strcpy(ToCreate,DirPath);
				strcat(ToCreate,Path);
				printf("To create is %s\n",ToCreate);
					if((File=fopen(ToCreate,"w"))!=NULL) {
						SendMessage(SockFd,"SEND\0");
						RecvFile(SockFd,File,ToCreate);
							fclose(File);
						} else {
							SendMessage(SockFd,"DONOTSEND\0");
						}	
			}
			RecvMessage(SockFd,Path);
		}
	}
}

void Penetrator(char *Ptr,int SockFd) {
	char Path[300];
	DIR *Dp;
	struct dirent *FileNames;
	struct stat *FileProp;
	strcpy(Path,Ptr);
	if((Dp=opendir(Ptr))!=NULL) {
		do {
			if((FileNames=readdir(Dp))!=NULL) {
				if(FileNames->d_type==8) {
					Check(FileNames,Path,0,SockFd);
				} else if(FileNames->d_type==4 && ((strcmp(FileNames->d_name,".."))!=0) && ((strcmp(FileNames->d_name,"."))!=0) ) {
					sprintf(Path,"%s/%s",Path,FileNames->d_name);
					Check(FileNames,Path,1,SockFd);					
					Penetrator(Path,SockFd);
					sprintf(Path,"%s",Ptr);
				}
			} 
		} while(FileNames!=NULL);
		closedir(Dp);
	} 
}

void Check(struct dirent *FileName,char *Ptr,int Type,int SockFd) {
	char *Path=(char *) malloc((sizeof(char)*(TEMPSIZE*10)));
	char *Status=(char *) malloc((sizeof(char)*(TEMPSIZE)));
	struct stat Buffer;
	int Fd;
	if(Type==0) {
		sprintf(Path,"%s/%s",Ptr,FileName->d_name);	
		SendMessage(SockFd,Path);
		if((Fd=open(Path,O_RDONLY))!=-1) {
			fstat(Fd,&Buffer);
			RecvMessage(SockFd,Status);
			if((strcmp(Status,"SEND"))==0) {
				SendFile(SockFd,Fd,(int) Buffer.st_size,Path);
			}
		}
	} else if(Type==1) {
		sprintf(Path,"%s/",Ptr);	
		SendMessage(SockFd,Path);
	}
	free(Path);
}
